/*global jQuery, Drupal,  VEShapeLayer, VEShapeSourceSpecification, VEDataType, VEMap, VELatLong */
var map = null;
var ogdi = { 'data': [] };

var toggleLoader = function (state) {
    if (state) {
        jQuery('#mapDiv').css('opacity', 0.5);
        jQuery('#loading').show();
    } else {
        jQuery('#mapDiv').css('opacity', 1);
        jQuery('#loading').hide();
    }
};

var fetchAndAttach = function (ent_type, filter) {
    try {
        filter = (filter ? '?$filter=' + encodeURIComponent(filter) + '&' : '?');
        var url = 'http://ogdi.cloudapp.net/v1/dc/' + ent_type + '/' + filter + 'format=kml';
        var layer = ogdi.data[ent_type] || new VEShapeLayer();
        var entity = ent_type;
        var shapeSpec = new VEShapeSourceSpecification(VEDataType.ImportXML, url, layer);
        map.ImportShapeLayerData(shapeSpec, function () {
            jQuery(layer.Annotations).each(function (idx, pin) {
            	
            	//alert(idx +':'+ pin);
                if (entity == 'CrimeIncidents') 
                {
                	// CrimeIncidents get a heat map
	                // @todo - make this configurable with Drupal.settings (icon per entity type, or "use heatmap" toggle)
	                //pin.SetCustomIcon('<img src="' + Drupal.settings.odata_ogdi.heat_icon + '" />');
                	pin.SetCustomIcon('<img src="' + CrimeIncident + '" style="width: 35px;" />');
	                pin.SetZIndex(1000);
                }
                else if(entity == 'BuildingPermits') 
                {
                	//pin.SetCustomIcon('<img src="' + Drupal.settings.odata_ogdi.upload_icon + '" />');
                	
                	pin.SetCustomIcon('<img src="' + BuildingPermit + '" style="width: 35px;" />');
                	pin.SetZIndex(1000);
                }
                else if(entity == 'CurrentConstructionProjects') 
                {
                	//pin.SetCustomIcon('<img src="' + Drupal.settings.odata_ogdi.upload_icon + '" />');
                	
                	pin.SetCustomIcon('<img src="' + CurrentConstructionProject + '" style="width: 35px;" />');
                	pin.SetZIndex(1000);
                }
                else 
                {
                	pin.SetZIndex(1001);
                }
                
                });
            toggleLoader(false);
            }, false);
        ogdi.data[ent_type] = shapeSpec.Layer;
    } catch (err) {
        // If the layer failed to load, suppress the error
        return;
    }

};


var processClick = function (ev) {
    if (ev.elementID) { // only process when something is clicked
        try {
            var element = map.GetShapeByID(ev.elementID);
            if (m = element.SourceUrl.match(/dc\/(\w+)\//)) {
                var url = Drupal.settings.basePath + 'ogdi/render/' + encodeURIComponent(m[1]) + '/' + element.Notes;
				//var url = '/ogdi/render/' + encodeURIComponent(m[1]) + '/' + element.Notes;
                toggleLoader(true);
                jQuery.get(url, {}, function (data, tStatus, xhr) {
                    jQuery('#dataTable').html(data);
                    toggleLoader(false);
                });
            }
        } catch (err) {
            // something broke, so display an error
            jQuery('#dataTable').html('An error occurred while loading data.');
            toggleLoader(false);
        }
    }
};

var reloadData = function () {
    toggleLoader(true);
    var view = map.GetMapView();
    var latA = view.TopLeftLatLong.Latitude;
    var latB = view.BottomRightLatLong.Latitude;
    var lonA = view.TopLeftLatLong.Longitude;
    var lonB = view.BottomRightLatLong.Longitude;

    var minLat = (latA > latB) ? latB : latA;
    var maxLat = (latA > latB) ? latA : latB;
    var minLon = (lonA > lonB) ? lonB : lonA;
    var maxLon = (lonA > lonB) ? lonA : lonB;
    var filter = 'latitude ge ' + minLat + ' and latitude le ' + maxLat;
    filter += ' and longitude ge ' + minLon + ' and longitude le ' + maxLon;

    for (layer in ogdi.data) {
        try {
        map.DeleteShapeLayer(layer);
        } catch (err) {
            // suppress
        }
    }

    for (index in Drupal.settings.odata_ogdi.entities) {
        fetchAndAttach(Drupal.settings.odata_ogdi.entities[index], filter);
    }
};

var getMap = function () {
    try {
        map = new VEMap('mapDiv');
        map.SetCredentials(Drupal.settings.odata_ogdi.bing_maps_key);
    
        map.LoadMap();
        var dc = new VELatLong(38.89859, -77.035971); // the White House
        map.SetCenterAndZoom(dc, 13);
    
        map.AttachEvent("onchangeview", reloadData);
        map.AttachEvent("onclick", processClick);
        reloadData({ 'property': false });
    } catch (err) {
        // If the map fails to load, give up
        return;
    }
};

// @todo for some reason this doesn't always fire correctly without a short timeout
jQuery(function () {
    setTimeout(getMap, 200);
});

