/*global jQuery, window */
var ODATA = (function ($) {
    // module export
    var my = {};
    my.history = [];

    my.enable = function (id) {
        $('#query-' + id).toggle();
        return false;
    };

    my.histCommand = function (id) {
        if (my.history[id].length < 2) {
            $('#back-' + id).replaceWith($('<span>').attr('id', 'back-' + id).text($('#back-' + id).text()));
        }

        var target = $('input[type=text]', $('#querybuilder-' + id).parent());
        target.attr('value', decodeURIComponent(my.history[id].pop()));
        $('#querybuilder-' + id).css('opacity', 0.5);
        target.blur();
        return false;
    };

    my.next = function (offset, id) {
        var target = $('input[type=text]', $('#querybuilder-' + id).parent()),
            limit;
        if (target.val().match(/\$top=/)) {
            limit = parseInt(target.val().match(/\$top=(\d+)/)[1], 10);
        } else {
            limit = parseInt(Drupal.settings.odata_support.page_limit, 10);
        }
        return updateOffset(offset + limit, id);
    };

    my.prev = function (offset, id) {
        var target = $('input[type=text]', $('#querybuilder-' + id).parent()),
            limit;
        if (target.val().match(/\$top=/)) {
            limit = parseInt(target.val().match(/\$top=(\d+)/)[1], 10);
        } else {
            limit = parseInt(Drupal.settings.odata_support.page_limit, 10);
        }
        return updateOffset(offset - limit, id);
    };

    my.populateQuery = function (key, value, id) {
        var query = decodeURIComponent($('input[type=text]', $('#querybuilder-' + id).parent()).attr('value'));
        // quote non-numeric values
        if (value.match(/[^0-9\.]/)) {
            value = "'" + value + "'";
        }
        var filter = '$filter=' + key + "%20eq%20" + value;
        if (!query.match(/\?/)) {
            query += '?';
        }
        if (query.match(/\$filter/)) {
            query = query.replace(/\$filter=[^&]+/, filter);
        } else {
            query = query + (query.match(/\?/) ? '&' : '?') + filter;
        }
        // reset paging as we're fetching a different result set
        query = query.replace(/&?\$skip=(\d+)/, '');
        return my.setQuery(query, id);
    };

    my.populateEntity = function (elem, id) {
    	return my.setQuery($(elem).text(), id);
        
    };

    my.setQuery = function (query, id) {
        var target = $('input[type=text]', $('#querybuilder-' + id).parent());
        updateHistory(target.attr('value'), id);
        target.attr('value', (query));
        //$('#querybuilder-' + id).css('opacity', 0.5);
        $('#querybuilder-' + id).html('<div class="loadcss" id="overlay-titlebar"><div id="overlay-title-wrapper"><h1 id="overlay-title" style="color: #000000; font-size:17px; margin-left: 18px; margin-bottom: 10px; padding-bottom: 0px; margin-top: 0px;">Loading...</h1></div></div>');
        target.blur();
        
        return false;
    };

    // init
    $(function () {
    	/*
        $('div.endpoint select').change(function () {
        	var id = $(this).parent().parent().attr('id').replace(/endpoint-/, '');
            $('#query-' + id + ' input').attr('value', '').blur();
        });
        */
        
        $('div.endpoint select').live('change', function() {
        	var id = $(this).parent().parent().attr('id').replace(/endpoint-/, '');
            $('#query-' + id + ' input').attr('value', '').blur();
		});

        // Disable Drupal's error reporting alert(), which is bad UX
        // This may result in a long-running script notice for extremely large result sets
        Drupal.ajax.prototype.error = function() {};
                
    });


    // private functions
    function updateHistory(query, id) {
        if (!my.history[id]) {
            my.history[id] = [];
        }
        $('#back-' + id).replaceWith(
            $('<a>').attr('id', 'back-' + id).text($('#back-' + id).text()).click(function () {
                my.histCommand(id);
            })
        );
        my.history[id].push(query);
    }
    
    function updateOffset(offset, id) {
        var query = $('input[type=text]', $('#querybuilder-' + id).parent()).val();
        if (query.match(/\$skip=(\d+)/)) {
            query = query.replace(/\$skip=(\d+)\b/, '$skip=' + offset);
        } else {
            query = query + (query.match(/\?/) ? '&' : '?') + '$skip=' + offset;
        }
        return my.setQuery(query, id);
    }


    // return the module
    return my;
}(jQuery));